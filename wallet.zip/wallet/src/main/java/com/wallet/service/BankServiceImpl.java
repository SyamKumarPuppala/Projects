package com.wallet.service;

import com.wallet.bean.Customer;
import com.wallet.dao.BankDao;
import com.wallet.dao.BankDaoImpl;

public class BankServiceImpl implements BankService {
	Customer temp = new Customer();
	BankDao dao;
	String pt,s = null;
	 public BankServiceImpl() {
		 dao = new BankDaoImpl();
		 
	}
	 
	 static String namePattern = "[A-Z]{1}[a-z]{2,}";
	 static String numberPattern = "(\\d){10}";
	 static String passwordPattern = "[A-Z]{1}[a-z]{2,6}(\\d){1,4}(\\W){1}";
	
	@Override
	public int addAccDao(Customer a) {
		
		return dao.accCreation(a);
	}

	@Override
	public double depositDao(double money) {
		int id = temp.getAccNum();
		if(temp.getTransaction()==null) {
			temp.setTransaction(" Account No: "+id+" amount "+money+ " deposited" + "\n");
		}
		else {
		pt = temp.getTransaction();
		String s=" Account No: "+id+" amount "+money+ " deposited" + "\n";
		pt += s;
		temp.setTransaction(pt); }
		temp.setCustBal(temp.getCustBal()+money);
		dao.updateDetails(temp.getAccNum(),temp);
		return temp.getCustBal();
	}

	@Override
	public double withdrawDao(double money) {
		if(money<temp.getCustBal()) {
			int id = temp.getAccNum();
			if(temp.getTransaction()==null) {
				temp.setTransaction(" Account No:"+id+"amount "+money+ " withdrawn" + "\n");
			}
			else {
			pt = temp.getTransaction();
			String s=" Account No:"+id+"amount "+money+ " withdrawn" + "\n";
			pt+=s; }
		temp.setCustBal(temp.getCustBal()-money);
		dao.updateDetails(temp.getAccNum(),temp);
		}
		else
			System.out.println("Low Balance :( ");
		return temp.getCustBal();
	}

	@Override
	public double showBalDao() {
		
		return temp.getCustBal();
	}
public  boolean validateCustName(String name)
{	if(name.matches(namePattern))
		return true;
	else
		return false;
	
}
public  boolean validateCustPhoneNumber(String number) {
	if(number.matches(numberPattern))
		return true;
	else
		return false;
}

public boolean validateCustAge(int age) {
	if(age<=110&&age>=1)
		return true;
	else
		return false;
	
}

public  boolean validateCustPwd(String pwd) {
	if(pwd.matches(passwordPattern))
		return true;
	else
		return false;
}

public  boolean validateAmt(double amt) {
if(amt>0.00)
	return true;
else
	return false;
}
@Override
public boolean checkLogin(int accNo) {
	temp =dao.loginUser(accNo);
	if(temp!=null)
	return true;
	else 
		return false;
}
@Override
public boolean checkPassword(String pwd) {
	
	if(temp.getCustPwd().matches(pwd))
		return true;
	else
		return false;

	
}

@Override
public String currentUser() {
	
	return temp.getCustName();
}

@Override
public boolean transferAmt(int toAccNo, double money) {
	Customer ftTemp =new Customer();
	if(temp.getCustBal()>=money) {
	ftTemp = dao.loginUser(toAccNo);
	if(ftTemp!=null)
	{
		int id = temp.getAccNum();
		if(temp.getTransaction()==null) {
			temp.setTransaction("Account No: "+id+" amount "+money+ " trnferred to "+ftTemp.getAccNum());
		}
		else {
			pt = temp.getTransaction();
			s=" Account No: "+id+" amount "+money+ " transferred to "+ftTemp.getAccNum() + "\n";
			pt+=s;
			temp.setTransaction(pt);
		}
		
		ftTemp.setCustBal(ftTemp.getCustBal()+money);
		temp.setCustBal(temp.getCustBal()-money);
		dao.updateDetails(temp.getAccNum(), temp);
		dao.updateDetails(ftTemp.getAccNum(), ftTemp);
		return true;
	}
	
	
}
	else if(temp.getCustBal()<money)
	{
		System.out.println("Low Balance to transfer");
	}
	
	else
		System.out.println("No such user account");
	return false;
}

@Override
public String showTrans() {
	// TODO Auto-generated method stub
	return temp.getTransaction();
}
}