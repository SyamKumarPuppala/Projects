package com.wallet.service;

import com.wallet.bean.Customer;

public interface BankService {

	int addAccDao(Customer a);
	double depositDao(double money);
	double withdrawDao(double money) ;
	double showBalDao();
	boolean checkLogin(int accNo);
	boolean checkPassword(String pwd);
	String currentUser();
	public String showTrans();
	boolean transferAmt(int toAccNo, double money);
	
}
