
package com.wallet.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.wallet.bean.Customer;

import com.wallet.dao.BankDaoImpl;
import com.wallet.service.BankServiceImpl;

import junit.framework.Assert;

public class BankTest {
	BankServiceImpl check = new BankServiceImpl();
	@Test
	public void testValidatePhoneNo() {
		//BankServiceImpl check = new BankServiceImpl();
	
	Assert.assertEquals(true, check.validateCustPhoneNumber("9874563210"));
		
	}
	
	@Test
	public void testValidateName() {
		//BankServiceImpl check = new BankServiceImpl();
		
	Assert.assertEquals(true,check.validateCustName("Peter") );
		
	}
	
	@Test
	public void testValidatePwd() {
		//BankServiceImpl check = new BankServiceImpl();
	
	Assert.assertEquals(true, check.validateCustPwd("Abcd123@"));
		
	}

	@Test
	public void testValidateAge()
	{
		//BankServiceImpl check = new BankServiceImpl();
		Assert.assertEquals(true, check.validateCustAge(34));
	}
	
	@Test
	public void testValidateAmt()
	{
		//WalletBasicService check = new WalletBasicService();
		Assert.assertEquals(true, check.validateAmt(2000.00));
	}
	@Test
	public void testValidatePhoneNoFail() {
		//WalletBasicService check = new WalletBasicService();
	
	Assert.assertEquals(false, check.validateCustPhoneNumber("8745621212121"));
		
	}
	
	@Test
	public void testValidateNameFail() {
		//WalletBasicService check = new WalletBasicService();
	boolean i = check.validateCustName("Matt123");
	Assert.assertEquals(false, i);
		
	}
	
	@Test
	public void testValidatePwdFail() {
		//WalletBasicService check = new WalletBasicService();
	
	Assert.assertEquals(false, check.validateCustPwd("@! SAm.IY"));
		
	}

	@Test
	public void testValidateAgeFail()
	{
		//WalletBasicService check = new WalletBasicService();
		Assert.assertEquals(false, check.validateCustAge(152));
	}
	
	@Test
	public void testValidateAmtFail()
	{
		//WalletBasicService check = new WalletBasicService();
		Assert.assertEquals(false, check.validateAmt(0.00));
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testAccCreation()
	{
		BankDaoImpl w = new BankDaoImpl();
		Customer a = new Customer();
		Assert.assertEquals(1000,w.accCreation(a));
		Customer a1 = new Customer();
		Assert.assertEquals(1001,w.accCreation(a1));
		Customer a2 = new Customer();
		Assert.assertEquals(1002,w.accCreation(a2));
		
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testDepositAmt()
	{
		BankServiceImpl w = new BankServiceImpl(); 
		Assert.assertEquals(2000.00, w.depositDao(2000.00));
		Assert.assertEquals(4000.00, w.depositDao(2000.00));
		
	}
	@SuppressWarnings("deprecation")
	@Test
	public void testWithdrawAmt() throws Exception
	{
		BankServiceImpl w = new BankServiceImpl();
		Customer a9 = new Customer();
		
		Assert.assertEquals(4000.00, w.depositDao(4000.00));
		Assert.assertEquals(2000.00, w.withdrawDao(2000.00));
		Assert.assertEquals(10.00, w.withdrawDao(1990.00));
		
	}
	
	@Test
	public void testDispBal()
	{
		BankServiceImpl w = new BankServiceImpl();
		Customer a = new Customer();
		Assert.assertEquals(0.00,w.showBalDao());
		
		
	}
	
	@Test
	public void testLogin()
	{
		BankDaoImpl w = new BankDaoImpl();
		Customer a = new Customer();
		w.accCreation(a);
		Customer a1 = new Customer();;
		w.accCreation(a1);
		Customer a2 = new Customer();;
		w.accCreation(a2);
		Customer a3 = new Customer();
		w.accCreation(a3);
		System.out.println(a3.getAccNum());
		Assert.assertEquals(a1, w.loginUser(1004));
	}
}


