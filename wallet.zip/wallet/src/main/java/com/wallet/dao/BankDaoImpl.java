package com.wallet.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeMap;

import com.wallet.bean.Customer;

public class BankDaoImpl implements BankDao {

	TreeMap<Integer, Customer> map = new TreeMap<Integer, Customer>();
	
	
	@Override
	public int accCreation(Customer a) {
		a.setAccNum();
		map.put(a.getAccNum(), a);
		return a.getAccNum();
	}

	

	

	@Override
	public Customer loginUser(int accNo) {
		
		return map.get(accNo);		
	}





	@Override
	public void updateDetails(int accNo, Customer a) {
		map.replace(accNo, a);
		
	}

	

}
