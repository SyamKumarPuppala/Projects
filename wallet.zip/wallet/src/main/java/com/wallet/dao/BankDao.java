package com.wallet.dao;

import com.wallet.bean.Customer;

public interface BankDao {
	
	int accCreation(Customer a);
	
	Customer loginUser(int accNo);
	
	void updateDetails(int accNo, Customer a);

}
