package com.wallet.exception;

public class BankException extends Exception {
	public BankException() {
		super();
	}
	public BankException(String message) {
		super(message);
	}
}
