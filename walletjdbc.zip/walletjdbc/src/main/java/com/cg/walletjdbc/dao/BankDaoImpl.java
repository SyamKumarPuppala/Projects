package com.cg.walletjdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.cg.walletjdbc.bean.Customer;
import com.cg.walletjdbc.dbconnection.DBConnection;
import com.cg.walletjdbc.exception.BankException;


public class BankDaoImpl implements BankDao {

	Logger logger=Logger.getRootLogger();

	public BankDaoImpl() {
		
		PropertyConfigurator.configure("resources//log4j.properties");
	}
	

	public int accCreation(Customer a) throws BankException {

		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
     
       int queryResult=0;
       int Id=0;
       try
		{		
			preparedStatement = connection.prepareStatement(QueryMapper.INSERT_QUERY);
			
			preparedStatement.setString(1,a.getCustName());
			
			preparedStatement.setString(2,a.getCustPhoneNo());
			preparedStatement.setInt(3,a.getCustAge());
			preparedStatement.setDouble(4,a.getCustBal());
			preparedStatement.setString(5,a.getCustPwd());
					
			queryResult=preparedStatement.executeUpdate();
			
			
			preparedStatement = connection.prepareStatement(QueryMapper.CUSTOMERID_QUERY_SEQUENCE);
			
			resultSet=preparedStatement.executeQuery();
			

			if(resultSet.next())
			{
				Id=resultSet.getInt(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new BankException("Inserting new Customer details failed ");

			}
			else
			{
				logger.info("Customer details with account number"+resultSet+ " added successfully:");
				return Id;
			}
		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new BankException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new BankException("Error in closing db connection");	
			}
		}
     
	}
	public String loginUser(int accNo) throws BankException {
		
		/*return map.get(accNo);	*/
        Connection connection = DBConnection.getInstance().getConnection();	
		
		   PreparedStatement preparedStatement=null;		
		   ResultSet resultSet = null;
		
     
           int queryResult=0;
          String password="null";
          try
          {		
        	  preparedStatement = connection.prepareStatement(QueryMapper.LOGIN_QUERY);
			
			preparedStatement.setInt(1,accNo);
			
					
			queryResult=preparedStatement.executeUpdate();
			
			
			//preparedStatement = connection.prepareStatement(QueryMapper.CUSTOMERID_QUERY_SEQUENCE);
			
			resultSet=preparedStatement.executeQuery();
			
			
			
			
			if(resultSet.next())
			{
				password=resultSet.getString(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Login Failed ");
				throw new BankException("No Customer Found with  "+accNo);

			}
			else
			{
				/*logger.info("Customer details with account number"+resultSet+ " added successfully:");
				 * 
				 */
				return password;
			}
		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new BankException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new BankException("Error in closing db connection");	
			}
		}
	}
	/*public void updateDetails(int accNo, Customer a) {
		map.replace(accNo, a);
		
	}

	public Customer loginUser(int accNo) {
		
		return null;
	}*/

	public void updateDetails(int accNo, Customer a) {
	
		
	}


	public int deposit(int money, int accNo) throws BankException {
		Connection connection = DBConnection.getInstance().getConnection();	
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		PreparedStatement preparedStatement1=null;		
		ResultSet resultSet1 = null;
		int queryResult=0;
       double balance=0;
       try
       {		
     	  preparedStatement = connection.prepareStatement(QueryMapper.DEPOSIT_QUERY);
			
			preparedStatement.setInt(1,money);
			preparedStatement.setInt(2,accNo);
			queryResult=preparedStatement.executeUpdate();
						
			preparedStatement1 = connection.prepareStatement(QueryMapper.SHOWBALANCE_QUERY);
			preparedStatement1.setInt(1,accNo);
			resultSet1=preparedStatement1.executeQuery();
			if(resultSet1.next()) {
				balance=resultSet1.getDouble(1);
						
			}
			
			preparedStatement = connection.prepareStatement(QueryMapper.TINSERT_QUERY);
			preparedStatement.setInt(1,accNo);
			
			preparedStatement.setInt(2,accNo);
			preparedStatement.setString(3,"Deposit");
			preparedStatement.setDouble(4,money);
			preparedStatement.setDouble(5,balance);
					
			queryResult=preparedStatement.executeUpdate();
			
			
			preparedStatement = connection.prepareStatement(QueryMapper.TRANSACTIONID_QUERY_SEQUENCE);
			
			resultSet=preparedStatement.executeQuery();


			
			if(queryResult==0)
			{
				logger.error("Login Failed ");
				throw new BankException("No Customer Found with  "+accNo);

			}
			else
			{
				return (int)balance;
			}
		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new BankException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new BankException("Error in closing db connection");	
			}
		}
	}


	public int withdraw(int money, int accNo) throws BankException {
		Connection connection = DBConnection.getInstance().getConnection();	
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		PreparedStatement preparedStatement1=null;		
		ResultSet resultSet1 = null;
		int queryResult=0;
       double balance=0;
       try
       {	
    	   preparedStatement1 = connection.prepareStatement(QueryMapper.SHOWBALANCE_QUERY);
			preparedStatement1.setInt(1,accNo);
			resultSet1=preparedStatement1.executeQuery();

			if(resultSet1.next()) {
				balance=resultSet1.getDouble(1);
						
			} 
			if (balance > money) {
     	  preparedStatement = connection.prepareStatement(QueryMapper.WITHDRAW_QUERY);
			
			preparedStatement.setInt(1,money);
			preparedStatement.setInt(2,accNo);
			queryResult=preparedStatement.executeUpdate();
			preparedStatement1 = connection.prepareStatement(QueryMapper.SHOWBALANCE_QUERY);
			preparedStatement1.setInt(1,accNo);
			resultSet1=preparedStatement1.executeQuery();
			if(resultSet1.next()) {
				balance=resultSet1.getDouble(1);
						
			} 
			preparedStatement = connection.prepareStatement(QueryMapper.TINSERT_QUERY);
			preparedStatement.setInt(1,accNo);
			
			preparedStatement.setInt(2,accNo);
			preparedStatement.setString(3,"WithDraw");
			preparedStatement.setDouble(4,money);
			preparedStatement.setDouble(5,balance);
			queryResult=preparedStatement.executeUpdate();
			
			
			preparedStatement = connection.prepareStatement(QueryMapper.TRANSACTIONID_QUERY_SEQUENCE);
			
			resultSet=preparedStatement.executeQuery();
			 }
			else
				throw new BankException("Insuffficient Funds");
			
			preparedStatement1 = connection.prepareStatement(QueryMapper.SHOWBALANCE_QUERY);
			preparedStatement1.setInt(1,accNo);
			resultSet1=preparedStatement1.executeQuery();

			
			if(queryResult==0)
			{
				logger.error("Login Failed ");
				throw new BankException("No Customer Found with  "+accNo);

			}
			else
			{
				return (int)balance;
			}
		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new BankException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new BankException("Error in closing db connection");	
			}
		}
	}


	public int showbalance(int accNo) throws BankException {
		Connection connection = DBConnection.getInstance().getConnection();	
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		PreparedStatement preparedStatement1=null;		
		ResultSet resultSet1 = null;
		int queryResult=0;
       double balance=0;
       try
       {		
     	  preparedStatement = connection.prepareStatement(QueryMapper.DEPOSIT_QUERY);
			
			preparedStatement.setInt(1,0);
			preparedStatement.setInt(2,accNo);
			queryResult=preparedStatement.executeUpdate();
						
			preparedStatement1 = connection.prepareStatement(QueryMapper.SHOWBALANCE_QUERY);
			preparedStatement1.setInt(1,accNo);
			resultSet1=preparedStatement1.executeQuery();

			if(resultSet1.next()) {
				balance=resultSet1.getDouble(1);
						
			}
			if(queryResult==0)
			{
				logger.error("Login Failed ");
				throw new BankException("No Customer Found with  "+accNo);

			}
			else
			{
				return (int)balance;
			}
		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new BankException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new BankException("Error in closing db connection");	
			}
		}
	}


	public boolean CheckCustomer(int ftAccNo, String ftName) throws BankException {


		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
       String name=null;
       try
		{		
			preparedStatement = connection.prepareStatement(QueryMapper.SHOWCUSTOMER_QUERY);
			preparedStatement.setInt(1,ftAccNo);
			
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				name=resultSet.getString(1);
						
			}
	
			if(name.equals(ftName))
				return true;
			else
				return false;
		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new BankException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new BankException("Error in closing db connection");	
			}
		}
     
	
	}


	public boolean transferAmt(int accNo,int toAccNo, double money) throws BankException {
		Connection connection = DBConnection.getInstance().getConnection();	
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		PreparedStatement preparedStatement1=null;		
		ResultSet resultSet1 = null;
		int queryResult=0;
       double balance=0;
       try
       {	
    	   preparedStatement1 = connection.prepareStatement(QueryMapper.SHOWBALANCE_QUERY);
			preparedStatement1.setInt(1,accNo);
			resultSet1=preparedStatement1.executeQuery();

			if(resultSet1.next()) {
				balance=resultSet1.getDouble(1);
						
			}
			try {
				if (balance > money) {
					preparedStatement = connection.prepareStatement(QueryMapper.WITHDRAW_QUERY);
					
					preparedStatement.setInt(1,(int)money);
					preparedStatement.setInt(2,accNo);
					queryResult=preparedStatement.executeUpdate();
						try {
							
							preparedStatement = connection.prepareStatement(QueryMapper.DEPOSIT_QUERY);
							
							preparedStatement.setInt(1,(int)money);
							preparedStatement.setInt(2,toAccNo);
							queryResult=preparedStatement.executeUpdate();
							preparedStatement1 = connection.prepareStatement(QueryMapper.SHOWBALANCE_QUERY);
							preparedStatement1.setInt(1,accNo);
							resultSet1=preparedStatement1.executeQuery();

							if(resultSet1.next()) {
								balance=resultSet1.getDouble(1);
										
							}
									

									
									preparedStatement = connection.prepareStatement(QueryMapper.TINSERT_QUERY);
									preparedStatement.setInt(1,accNo);
									preparedStatement.setInt(2,toAccNo);
									preparedStatement.setString(3,"Transfer");
									preparedStatement.setDouble(4,money);
									preparedStatement.setDouble(5,balance);
									queryResult=preparedStatement.executeUpdate();
									preparedStatement = connection.prepareStatement(QueryMapper.TRANSACTIONID_QUERY_SEQUENCE);
									resultSet=preparedStatement.executeQuery();
									
									return true;
							
							
						} catch (Exception e) {
							throw new BankException("Insufficient Funds1");
						}
				}
				else
					throw new BankException("Insufficient Fund2");
			} catch (Exception e) {
				throw new BankException("Insufficient Funds3");
			}
			}
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new BankException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new BankException("Error in closing db connection");	
			}
		}

	}


	public boolean showTrans(int accNo) throws BankException {
Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		int queryResult=0;
		try {
			preparedStatement=connection.prepareStatement(QueryMapper.SELECT_TRANSACTIONS);
			preparedStatement.setInt(1,accNo);
			resultSet=preparedStatement.executeQuery();
			
			System.out.println("Transaction-id    From account    To account    Transaction type           Amount          Balance");
			while(resultSet.next()) 
{
				System.out.println("   "+resultSet.getInt(1)+"                "+resultSet.getInt(2)+"              "+resultSet.getInt(3)+"            "+resultSet.getString(4)+"           "+resultSet.getDouble(5)+"         "+resultSet.getDouble(6));
			}

			return true;
			
		}
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			throw new BankException("Tehnical problem occured refer log");
		} 
finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new BankException("Error in closing db connection");	
			} 
	
	}
	
	}
}