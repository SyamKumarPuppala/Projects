package com.cg.walletjdbc.service;
import com.cg.walletjdbc.bean.Customer;
import com.cg.walletjdbc.dao.BankDao;
import com.cg.walletjdbc.dao.BankDaoImpl;
import com.cg.walletjdbc.exception.BankException;

public class BankServiceImpl implements BankService {
	Customer temp = new Customer();
	BankDao dao;
	String pt,s = null;
	 public BankServiceImpl() {
		 dao = new BankDaoImpl();
		 
	}
	 
	 static String namePattern = "[A-Z]{1}[a-z]{2,}";
	 static String numberPattern = "(\\d){10}";
	 static String passwordPattern = "[A-Z]{1}[a-z]{2,6}(\\d){1,4}(\\W){1}";

	public int addAccDao(Customer a)  {
		
		
			try {
				return dao.accCreation(a);
			} catch (BankException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return 0;
		
	}
	public int depositDao(int money,int accNo) throws BankException {
		try {
			int amt = dao.deposit(money,accNo);
			return amt;
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
		
	}
	public int withdrawDao(int money,int accNo) {
		try {
			int amt = dao.withdraw(money,accNo);
			return amt;
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}
	public int showBalDao(int accNo) {
		
		try {
			int amt = dao.showbalance(accNo);
			System.out.println(amt+"haiii");
			return amt;
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}
	public  boolean validateCustName(String name)
	{	
		if(name.matches(namePattern))
			return true;
		else
			return false;
	
	}
public  boolean validateCustPhoneNumber(String number) {
	if(number.matches(numberPattern))
		return true;
	else
		return false;
}

public boolean validateCustAge(int age) {
	if(age<=110&&age>=1)
		return true;
	else
		return false;
	
}

public  boolean validateCustPwd(String pwd) {
	if(pwd.matches(passwordPattern))
		return true;
	else
		return false;
}

public  boolean validateAmt(double amt) {
if(amt>0.00)
	return true;
else
	return false;
}

public String checkLogin(int accNo) {
	String temp = null;
	try {
		temp = dao.loginUser(accNo);
	} catch (BankException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	return temp;
	
}

public boolean checkPassword(String pwd,int custAccId) {
	String temp = null;
	try {
		temp = dao.loginUser(custAccId);
	} catch (BankException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	/*System.out.println(temp+" "+pwd );*/
	if(temp.equals(pwd)) {
		/*System.out.println("true");*/
		return true;
	}
	else
		return false;

	
}


public String currentUser() {
	
	return temp.getCustName();
}

public boolean transferAmt(int accNo,int toAccNo, double money) {
	boolean t = false;
	try {
		 t = dao.transferAmt(accNo,toAccNo,money);
	} catch (BankException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	return t;
	
	
}


public boolean showTrans(int accNo) {
	boolean t = false;
	try {
		 t = dao.showTrans(accNo);
	} catch (BankException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	return t;
}
public boolean CheckCustomer(int ftAccNo, String ftName) throws BankException {
	boolean t = false;
	try {
		 t = dao.CheckCustomer(ftAccNo,ftName);
	} catch (BankException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	return t;
}
}