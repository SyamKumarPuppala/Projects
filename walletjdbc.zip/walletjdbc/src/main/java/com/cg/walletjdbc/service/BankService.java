package com.cg.walletjdbc.service;
import com.cg.walletjdbc.bean.Customer;
import com.cg.walletjdbc.exception.BankException;
public interface BankService {

	int addAccDao(Customer a);
	int depositDao(int money,int accNo) throws BankException;
	int withdrawDao(int money,int accNo) ;
	int showBalDao(int accNo) throws BankException;
	String checkLogin(int accNo);
	boolean CheckCustomer(int ftAccNo,String ftName) throws BankException;
	boolean checkPassword(String pwd,int custAccId);
	String currentUser();
	public boolean showTrans(int accNo) throws BankException ;
	boolean transferAmt(int accNo,int toAccNo, double money) throws BankException;
	
}
