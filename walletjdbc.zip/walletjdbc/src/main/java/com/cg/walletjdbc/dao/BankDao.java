package com.cg.walletjdbc.dao;
import com.cg.walletjdbc.bean.Customer;
import com.cg.walletjdbc.exception.BankException;

public interface BankDao {
	
	int accCreation(Customer a) throws BankException;
	
	public String loginUser(int accNo) throws BankException;
	public int deposit(int money,int accNo) throws BankException;
	public int withdraw(int money,int accNo) throws BankException;
	public int showbalance(int accNo) throws BankException;
	public boolean CheckCustomer(int ftAccNo,String ftName) throws BankException;
	void updateDetails(int accNo, Customer a);
	public boolean showTrans(int accNo) throws BankException;
	boolean transferAmt(int accNo,int toAccNo, double money) throws BankException;

}
