package com.cg.walletjdbc.dao;



public interface QueryMapper {
	public static final String INSERT_QUERY="INSERT INTO CUSTOMER2 VALUES(accNum_sequence2.NEXTVAL,?,?,?,?,?)";
	public static final String TINSERT_QUERY="INSERT INTO Transactions VALUES(transactionId_sequence.NEXTVAL,?,?,?,?,?)";
	public static final String CUSTOMERID_QUERY_SEQUENCE="SELECT accNum_sequence2.CURRVAL FROM DUAL";
	public static final String TRANSACTIONID_QUERY_SEQUENCE="SELECT transactionId_sequence.CURRVAL FROM DUAL";
	public static final String LOGIN_QUERY="SELECT custPwd FROM CUSTOMER2 WHERE accNum=?";
	public static final String DEPOSIT_QUERY="UPDATE CUSTOMER2 SET custBal=custBal+? WHERE accNum=?";
	public static final String WITHDRAW_QUERY="UPDATE CUSTOMER2 SET custBal=custBal-? WHERE accNum=?";
	public static final String SHOWBALANCE_QUERY="SELECT custBal FROM CUSTOMER2 WHERE accNum=?";
	public static final String SHOWCUSTOMER_QUERY="SELECT custName FROM CUSTOMER2 WHERE accNum=?";
	public static final String SHOWTRANSACTIONS_QUERY="SELECT * FROM TRANSACTIONS WHERE ((faccno=?))or(taccno=?))"; 
	public static final String SELECT_TRANSACTIONS="select * from Transactions where faccno=?"; 

}

/******************TABLESCRIPT*******************
CREATE TABLE CUSTOMER2
    (accNum NUMBER PRIMARY KEY,
	custName VARCHAR2(30),
	custPhoneNo VARCHAR2(30),
	custAge NUMBER,
	custBal NUMBER(10,3),

	custPwd VARCHAR2(20)   
);

CREATE SEQUENCE accNum_sequence2 start with 1000;

create table Transactions(
transactionId number(10),
faccno number(5),
taccno number(5),
type varchar2(10),
amount number(10,3),
balance number(10,3)
);

CREATE SEQUENCE transactionId_sequence start with 1000;

************************************************/