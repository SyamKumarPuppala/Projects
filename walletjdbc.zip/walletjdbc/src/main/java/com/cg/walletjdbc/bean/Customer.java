package com.cg.walletjdbc.bean;
public class Customer {
	private String transaction;
	public Customer() {}
	public Customer(String transaction, int accNum, String custName, String custPhoneNo, int custAge, double custBal,
			String custPwd) {
		super();
		this.transaction = transaction;
		this.accNum = accNum;
		this.custName = custName;
		this.custPhoneNo = custPhoneNo;
		this.custAge = custAge;
		this.custBal = custBal;
		this.custPwd = custPwd;
	}
	public String getTransaction() {
		return transaction;
	}
	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}
	private int accNum;
	private String custName;
	private String custPhoneNo;
	private int custAge;
	private double custBal;
	static private int accNumInitial = 1000;
	private String custPwd;
	public int getAccNum() {
		return accNum;
	}
	public void setAccNum() {
		this.accNum = accNumInitial++;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCustPhoneNo() {
		return custPhoneNo;
	}
	public void setCustPhoneNo(String custPhoneNo) {
		this.custPhoneNo = custPhoneNo;
	}
	public int getCustAge() {
		return custAge;
	}
	public void setCustAge(int custAge) {
		this.custAge = custAge;
	}
	public double getCustBal() {
		return custBal;
	}
	public void setCustBal(double custBal) {
		this.custBal = custBal;
	}
	public String getCustPwd() {
		return custPwd;
	}
	public void setCustPwd(String custPwd) {
		this.custPwd = custPwd;
	}
	
	
	
	

}
